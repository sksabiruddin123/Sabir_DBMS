/**
 * 
 */
/**
 * 
 */
module JDBCPROJECT {
	requires java.sql;
}