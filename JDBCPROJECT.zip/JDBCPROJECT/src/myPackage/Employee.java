package myPackage;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;


public class Employee {
    public static void main(String[] args) {
    	 Connection connection = null;
         try {
             // Establishing connection
             connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/GL", "root", "1212");

             // a. Insert 5 records
             insertRecords(connection);

             // b. Modify Email_Id column to varchar(30) NOT NULL
             modifyColumn(connection);

             // c. Insert 2 records and check
             insertRecords(connection);

             // d. Update the name of employee Id 3 to Karthik and phone number to 1234567890
             updateRecord(connection);

             // e. Delete employee records 3 and 4
            deleteRecords(connection);

             // f. Remove all records from the table employee
             removeAllRecords(connection);

         } catch (SQLException e) {
             e.printStackTrace();
         } finally {
             // Closing connection
             try {
                 if (connection != null) {
                     connection.close();
                 }
             } catch (SQLException e) {
                 e.printStackTrace();
             }
         }
     }

     // Method to insert 5 records
    private static void insertRecords(Connection connection) throws SQLException {
        String insertQuery = "INSERT INTO employee (Name, Email_Id, Phone_Number) VALUES (?, ?, ?)";
        PreparedStatement preparedStatement = connection.prepareStatement(insertQuery);

        // Inserting record 1
        preparedStatement.setString(1, "Employee1");
        preparedStatement.setString(2, "email1@example.com");
        preparedStatement.setString(3, "1234567891");
        preparedStatement.executeUpdate();

        // Inserting record 2
        preparedStatement.setString(1, "Employee2");
        preparedStatement.setString(2, "email2@example.com");
        preparedStatement.setString(3, "1234567892");
        preparedStatement.executeUpdate();

        // Inserting record 3
        preparedStatement.setString(1, "Employee3");
        preparedStatement.setString(2, "email3@example.com");
        preparedStatement.setString(3, "1234567893");
        preparedStatement.executeUpdate();

        // Inserting record 4
        preparedStatement.setString(1, "Employee4");
        preparedStatement.setString(2, "email4@example.com");
        preparedStatement.setString(3, "1234567894");
        preparedStatement.executeUpdate();

        // Inserting record 5
        preparedStatement.setString(1, "Employee5");
        preparedStatement.setString(2, "email5@example.com");
        preparedStatement.setString(3, "1234567895");
        preparedStatement.executeUpdate();

        preparedStatement.close();
    }

   
 
     // Method to modify Email_Id column
     private static void modifyColumn(Connection connection) throws SQLException {
         String modifyQuery = "ALTER TABLE employee MODIFY COLUMN Email_Id VARCHAR(30) NOT NULL";
         PreparedStatement preparedStatement = connection.prepareStatement(modifyQuery);
         preparedStatement.executeUpdate();
         preparedStatement.close();
     }

     // Method to update record
     private static void updateRecord(Connection connection) throws SQLException {
         String updateQuery = "UPDATE employee SET Name = ?, Phone_Number = ? WHERE Id = ?";
         PreparedStatement preparedStatement = connection.prepareStatement(updateQuery);
         preparedStatement.setString(1, "Karthik");
         preparedStatement.setString(2, "1234567890");
         preparedStatement.setInt(3, 3);
         preparedStatement.executeUpdate();
         preparedStatement.close();
     }

     // Method to delete records
     private static void deleteRecords(Connection connection) throws SQLException {
         String deleteQuery = "DELETE FROM employee WHERE Id IN (?, ?)";
         PreparedStatement preparedStatement = connection.prepareStatement(deleteQuery);
         preparedStatement.setInt(1, 3);
         preparedStatement.setInt(2, 4);
         preparedStatement.executeUpdate();
         preparedStatement.close();
     }

     // Method to remove all records
     private static void removeAllRecords(Connection connection) throws SQLException {
         String deleteAllQuery = "DELETE FROM employee";
         PreparedStatement preparedStatement = connection.prepareStatement(deleteAllQuery);
         preparedStatement.executeUpdate();
         preparedStatement.close();
       }
    }
   


